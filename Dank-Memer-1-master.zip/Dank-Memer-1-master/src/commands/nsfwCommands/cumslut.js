const { GenericMediaCommand } = require('../../models/');

module.exports = new GenericMediaCommand({
  triggers: ['cumslut'],
  description: 'cumsluts, ok',
  isNSFW: true,

  title: ':o',
  message: 'Free nudes thanks to boobbot & tom <3',
  JSONKey: 'url',
  donorOnly: true,
  reqURL: 'https://boob.bot/api/v2/img/cumsluts',
  tokenKey: 'boobbot'
});
