const { GenericImageCommand } = require('../../models/');

module.exports = new GenericImageCommand({
  triggers: ['disability', 'ken'],
  description: 'lol thanks ken.'
});
