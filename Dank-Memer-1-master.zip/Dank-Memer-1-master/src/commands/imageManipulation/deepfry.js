const { GenericImageCommand } = require('../../models/');

module.exports = new GenericImageCommand({
  triggers: ['deepfry'],
  description: '😂👌💯🔥'
});
