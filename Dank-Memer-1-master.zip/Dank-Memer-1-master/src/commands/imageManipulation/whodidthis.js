const { GenericImageCommand } = require('../../models/');

module.exports = new GenericImageCommand({
  triggers: ['whodidthis', 'wdt'],
  description: 'who did this 😂😂😂'
});
