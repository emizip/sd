## Developers

* **Mel** - *Owner and head developer* - [GitHub Profile](https://github.com/melmsie)
* **Aetheryx** - *Retired - Core infrastructure* - [GitHub Profile](https://github.com/Aetheryx)
* **CyberRonin** - *Dashboard and webhooks* [Github Profile](https://github.com/TheCyberRonin)
* **Kromatic** - *Image server and sound effects* [Github Profile](https://github.com/Devoxin)
* **Blake** - *didn't get 2000th commit* [Github Profile](https://github.com/zBlakee)
* **Paradox** - *didn't get 2000th commit* [Github Profile](https://github.com/ParadoxOrigins)
* **Yukine** - *New developer* [Github Profile](https://github.com/Dev-Yukine)
* **Perry** - *New developer that argues a lot* [Github Profile](https://github.com/perryprog)

See also the list of [contributors](https://github.com/melmsie/Dank-Memer/contributors) who participated in this project.
